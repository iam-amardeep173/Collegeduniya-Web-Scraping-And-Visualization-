import csv
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.edge.options import Options
from selenium.webdriver.edge.service import Service


class CollegeData:
    def __init__(self, name, location, course_fees, courses, placement, review, no_of_reviews, ranking):
        self.name = name
        self.location = location
        self.course_fees = course_fees
        self.courses = courses
        self.placement = placement
        self.review = review
        self.no_of_reviews = no_of_reviews
        self.ranking = ranking


def make_request(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    options = Options()
    options.add_argument('headless')

    try:
        path = 'E:\Mtech\DS_scrap\mtech1_ds\Include\edgedriver_win64\msedgedriver.exe'
        service = Service(path)
        driver = webdriver.Edge(service=service, options=options)
        response = requests.get(url, headers=headers)
        driver.implicitly_wait(200)
        response.raise_for_status()
        page_source = response.content
    except requests.exceptions.HTTPError as e:
        print(f"Error in making the request with requests module: {e}")
        print("Falling back to Selenium for requests.")
        page_source = driver.page_source
    finally:
        if driver:
            driver.quit()

    return page_source


def scrape_website(url):
    college_data_list = []

    # Make a GET request
    page_source = make_request(url)
    if page_source is None:
        return None

    # Parse the HTML content
    soup = BeautifulSoup(page_source, 'html.parser')

    # Find all relevant elements
    colleges = soup.find_all('tr', class_=['jsx-3462784614 table-row even', 'jsx-3462784614 table-row odd'])

    # Extract data for each college
    for college in colleges:
        name = college.find('h3', class_='jsx-3462784614 font-weight-medium text-lg mb-0')
        location = college.find('div', class_='jsx-3462784614 mt-1 font-weight-medium text-sm')
        course_fees = college.find('span', class_='jsx-3462784614 text-lg text-green d-block font-weight-bold mb-1')
        courses = college.find('span', class_='jsx-3462784614 fee-shorm-form')
        placement = college.find('span', class_='jsx-3462784614 mb-2')
        review = college.find('span', class_='jsx-3462784614 lr-key text-lg text-primary d-block font-weight-medium mb-1')
        no_of_reviews = college.find('span', class_='jsx-3462784614 lr-value d-block font-weight-medium text-sm')
        ranking = college.find('span', class_='jsx-2794970405 rank-container pointer d-block font-weight-medium text-dark-gray text-lg')

        college_data = CollegeData(
            name.text if name else 'Na',
            location.text if location else 'Na',
            course_fees.text if course_fees else 'Na',
            courses.text if courses else 'Na',
            placement.text if placement else 'Na',
            review.text if review else 'Na',
            no_of_reviews.text if no_of_reviews else 'Na',
            ranking.text if ranking else 'Na'
        )

        college_data_list.append(college_data)

    return college_data_list


def write_to_csv(data_list, file_path='colleges_data.csv'):
    with open(file_path, 'a', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Name', 'Location', 'Course Fees', 'Courses', 'Placement', 'Review', 'Number of Reviews', 'Ranking']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        # Write the header
        writer.writeheader()

        # Write the data
        for college_data in data_list:
            writer.writerow({
                'Name': college_data.name,
                'Location': college_data.location,
                'Course Fees': college_data.course_fees,
                'Courses': college_data.courses,
                'Placement': college_data.placement,
                'Review': college_data.review,
                'Number of Reviews': college_data.no_of_reviews,
                'Ranking': college_data.ranking
            })


def main(url):
    college_data_list = scrape_website(url)

    if college_data_list is not None:
        # Process the scraped data (for example, print it)
        for college_data in college_data_list:
            print("Name:", college_data.name)
            print("Location:", college_data.location)
            print("Course Fees:", college_data.course_fees)
            print("Courses:", college_data.courses)
            print("Placement:", college_data.placement)
            print("Review:", college_data.review)
            print("Number of Reviews:", college_data.no_of_reviews)
            print("Ranking:", college_data.ranking)
            print("\n")

        # Write data to CSV
        write_to_csv(college_data_list)
        print("Data written to CSV.")
    else:
        print("No data available.")


if __name__ == "__main__":
    branch=input("Enter the branch (B.Tech, MBA, M.Tech, MBBS, B.Com, B.Sc, bsc-nursing, BA, BBa, BCA)  : \t ")
    # Replace 'your_url_here' with the actual URL you want to scrape
    url_to_scrape = f'https://collegedunia.com/{branch}-colleges'
    main(url_to_scrape)





# def make_request(url):
#     options = Options()
#     options.add_argument('headless')

#     try:
#         path = 'E:\Mtech\DS_scrap\mtech1_ds\Include\edgedriver_win64\msedgedriver.exe'
#         service = Service(path)
#         driver = webdriver.Edge(service=service, options=options)
        
#         headers = {
#         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
#         }
#         driver.get(url, headers=headers)
#         driver.implicitly_wait(5)  # Adjust wait time as needed

#         # Execute JavaScript to scroll to the end of the page
#         script = """
#         window.scrollTo(0, document.body.scrollHeight);
#         """
#         driver.execute_script(script)

#         # Wait for some time to let the page update (adjust as needed)
#         driver.implicitly_wait(10)

#         # Get HTML content from the Selenium driver after scrolling to the end
#         html_content = driver.page_source
#         print(html_content)
#         print("hiih")
#     except Exception as e:
#         print(f"Error in making the request with Selenium: {e}")
#         html_content = None
#     finally:
#         if driver:
#             driver.quit()

#     return html_content